﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using WebNodeMng.Models;

namespace WebNodeMng.Controllers
{
    public class NodeController : Controller
    {
        NodeManager nodeManager = new NodeManager("", "");
        
        // GET: Node
        public ActionResult Index()
        {
            if (ViewBag.uuMax == null)
                ViewBag.uuMax = Node.UploadUtilization_MaxThreshold;  // nodeManager.UploadUtilization_MaxThreshold;

            if (ViewBag.duMax == null)
                ViewBag.duMax = Node.DownloadUtilization_MaxThreshold;

            if (ViewBag.erMax == null)
                ViewBag.erMax = Node.ErrorRate_MaxThreshold;

            if (ViewBag.ccMax == null)
                ViewBag.ccMax = Node.ConnectedClients_MaxThreshold;

            return View(nodeManager.GetNodes());
        }

        // GET: Node/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Node/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                Node node = new Node(nodeManager.GetNodes().Count + 1, collection["Name"], collection["City"]);
                
                nodeManager.AddNode(node);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Node/Edit/5 
        public ActionResult Edit(int id)
        {
            return View(nodeManager.GetNode(id));
        }

        // POST: Node/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                Node node = nodeManager.GetNode(id);
                node.UpdateNode(collection["Name"], collection["City"], true /* collection["isOnline"] */ );
                
                return RedirectToAction("Index");
            }
            catch
            {
                return View(nodeManager.GetNode(id));
            }
        }

        // GET: Node/Delete/5
        public ActionResult Delete(int id)
        {
            return View(nodeManager.GetNode(id));
        }

        // POST: Node/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
 
                nodeManager.RemoveNode(id);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        /*
        [HttpPost]
        public string SetMaxThresholdValues(string uploadUtilization,
                                   string downloadUtilization,
                                   string errorRate,
                                   string connectedClients)
        {
            return "success";
        }

        [HttpPost]
        public string SetNodeOnline(string flag)
        {
            return "";
        }
        */
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using WebNodeMng.Models;

namespace WebNodeMng.Controllers
{
    public class NodeManagerController : Controller
    {
        NodeManager nodeManager = new NodeManager();

        // GET: NodeManager
        public ActionResult Index()
        {
            return View();
        }

        // GET: NodeManager/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: NodeManager/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: NodeManager/Edit/5
        public ActionResult Edit(int id)
        {
            nodeManager = new NodeManager("User1", "Operator");   // for test simplification
            return View(nodeManager);
        }

        // POST: NodeManager/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                if (nodeManager == null)
                {
                    nodeManager = new NodeManager("", "");
                }

                float uuMax = 0.0f;
                float duMax = 0.0f;
                float erMax = 0.0f;
                uint  ccMax = 0;

                float.TryParse(collection["UploadUtilization_MaxThreshold"], out uuMax);
                float.TryParse(collection["DownloadUtilization_MaxThreshold"], out duMax);
                float.TryParse(collection["ErrorRate_MaxThreshold"], out erMax);
                uint.TryParse(collection["ConnectedClients_MaxThreshold"], out ccMax);

                nodeManager.Update(collection["Name"], collection["Title"], uuMax, duMax, erMax, ccMax);
                //ViewBag.uuMax = uuMax;
                //ViewBag.duMax = duMax;
                //ViewBag.erMax = erMax;
                //ViewBag.ccMax = ccMax;

                return RedirectToAction("Index", "Node");
            }
            catch
            {
                return View(nodeManager);
            }
        }

        // GET: NodeManager/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: NodeManager/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}

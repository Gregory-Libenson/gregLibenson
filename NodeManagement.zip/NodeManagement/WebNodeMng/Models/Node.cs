﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace WebNodeMng.Models
{
    public class Node 
    {
        // Class Level Properties

        public static float UploadUtilization_MaxThreshold { get; private set; }
        public static float DownloadUtilization_MaxThreshold { get; private set; }
        public static float ErrorRate_MaxThreshold { get; private set; }
        public static uint ConnectedClients_MaxThreshold { get; private set; }

        // Instance Level Properties

        private readonly Random _rnd;

        #region Properties
        // Basic properties

        [DisplayName("Node Id")]
        public int NodeId { get; private set; }

        [DisplayName("Name")]
        public string Name { get; private set; }

        [DisplayName("City")]
        public string City { get; private set; }

        // State

        [DisplayName("Online Time")]
        public DateTime OnlineTime { get; private set; }

        [DisplayName("Is Online")]
        public bool IsOnline { get; private set; }

        // Metrics

        [DisplayName("Upload Utilization")]
        public float UploadUtilization { get; private set; }

        [DisplayName("Download Utilization")]
        public float DownloadUtilization  { get; private set; }

        [DisplayName("Error Rate")]
        public float ErrorRate { get; private set; }

        [DisplayName("Connected Clients")]
        public uint ConnectedClients { get; private set; }

        // Flags if Telemetry Metrics Values exceed Threshold Max          
        public bool uu_exceedMaxFlag { get; private set; }
        public bool du_exceedMaxFlag { get; private set; }
        public bool er_exceedMaxFlag { get; private set; }
        public bool cc_exceedMaxFlag { get; private set; }

        #endregion

        #region Initialization
        public Node(int nodeId, string name, string city)
        {
            _rnd = new Random();

            NodeId = nodeId;
            Name = name;
            City = city;

            OnlineTime = DateTime.Now;

            IsOnline = true;  // false;

            SimulateRandomMetrics();  // ResetMetrics();
        }
        public Node(int nodeId, string name, string city, Random rnd)
        {
            _rnd = rnd;

            NodeId = nodeId;
            Name = name;
            City = city;

            OnlineTime = DateTime.Now;

            IsOnline = false;

            ResetMetrics();
        }

        #endregion

        #region Public Methods
        public void SetOnline()
        {
            IsOnline = true;

            SimulateRandomMetrics();
        }

        public void SetOffline()
        {
            IsOnline = false;
            
            ResetMetrics();           
        }

        public static string SetMaxThresholdValues(float uploadUtilization_MaxThreshold,
                          float downloadUtilization_MaxThreshold,
                          float errorRate_MaxThreshold,
                          uint connectedClients_MaxThreshold)
        {
            UploadUtilization_MaxThreshold = uploadUtilization_MaxThreshold;
            DownloadUtilization_MaxThreshold = downloadUtilization_MaxThreshold;
            ErrorRate_MaxThreshold = errorRate_MaxThreshold;
            ConnectedClients_MaxThreshold = connectedClients_MaxThreshold;

            return "";
        }

        #endregion

        #region Private Methods
        private void ResetMetrics()
        {
            // Clear metrics back to 0.

            UploadUtilization = 0.0f;
            DownloadUtilization = 0.0f;
            ErrorRate = 0.0f;
            ConnectedClients = 0;

            uu_exceedMaxFlag = false; 
            du_exceedMaxFlag = false;
            er_exceedMaxFlag = false;
            cc_exceedMaxFlag = false;
        }

        private void SimulateRandomMetrics()
        {
            // Generate random values to simulate metrics.

            UploadUtilization = (float) _rnd.NextDouble() * 100;
            DownloadUtilization = (float) _rnd.NextDouble() * 100;
            ErrorRate = (float) _rnd.NextDouble() * 100;
            ConnectedClients = (uint) _rnd.Next(1, 500) * 100;

            CheckMetrixValues();
        }

        public void CheckMetrixValues()
        {
            uu_exceedMaxFlag = UploadUtilization > UploadUtilization_MaxThreshold && UploadUtilization_MaxThreshold > 0;
            du_exceedMaxFlag = DownloadUtilization > DownloadUtilization_MaxThreshold && DownloadUtilization_MaxThreshold > 0;
            er_exceedMaxFlag = ErrorRate > ErrorRate_MaxThreshold && ErrorRate_MaxThreshold > 0;
            cc_exceedMaxFlag = ConnectedClients > ConnectedClients_MaxThreshold && ConnectedClients_MaxThreshold > 0;
        }

        public void UpdateNode(string name, string city, bool isOnline)
        {
            Name = name;
            City = city;
            IsOnline = isOnline;

            if (isOnline)
            {
                SetOnline();
            }
            else
            {
                SetOffline();
            }

        }
    #endregion
    }
}

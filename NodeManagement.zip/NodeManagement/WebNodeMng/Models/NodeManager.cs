﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace WebNodeMng.Models
{
    public class NodeManager 
    {
        private static readonly List<Node> _nodes = new List<Node>();

        public int NodeManagerId = 1;  // shortcut for simplification

        [DisplayName("Name")]
        public string Name { get; private set; }

        [DisplayName("Title")]
        public string Title { get; private set; }

        [DisplayName("Upload Utilization")]
        public float UploadUtilization_MaxThreshold { get; private set; }

        [DisplayName("Download Utilization")]
        public float DownloadUtilization_MaxThreshold { get; private set; }

        [DisplayName("Error Rate")]
        public float ErrorRate_MaxThreshold { get; private set; }

        [DisplayName("Connected Clients")]
        public uint ConnectedClients_MaxThreshold { get; private set; }

        public NodeManager()
        {
        }

        public NodeManager(string name, string title)
        {            
            Name = name;
            Title = title;
        }

        public void Update(string name, string title, float uu, float du, float er, uint cc)
        {
            Name = name;
            Title = title;
            UploadUtilization_MaxThreshold = uu;
            DownloadUtilization_MaxThreshold = du;
            ErrorRate_MaxThreshold = er;
            ConnectedClients_MaxThreshold = cc;

            Node.SetMaxThresholdValues(uu, du, er, cc);

            foreach (Node node in _nodes)
            {
                if (node.IsOnline && node.UploadUtilization > UploadUtilization_MaxThreshold)
                {
                    node.CheckMetrixValues();
                }
            }
        }

        public void AddNode(Node node)
        {
            if (!_nodes.Exists(x => x.NodeId == node.NodeId))
            {
                _nodes.Add(node);
            }
            else
            {
                throw new Exception(string.Format("Cannot add node. NodeId {0} already exists.", node.NodeId));
            }
        }

        public void RemoveNode(int nodeId)
        {
            var existingNode = GetNode(nodeId);

            if (existingNode != null)
            {
                _nodes.Remove(existingNode);
            }
            else
            {
                throw new Exception(string.Format("Cannot remove node. NodeId {0} does not exist", nodeId));
            }
        }

        public Node GetNode(int nodeId)
        {
            return _nodes.Find(x => x.NodeId == nodeId);
        }

        public ICollection<Node> GetNodes()
        {
            return _nodes;
        }

        public string SetMaxThresholdValues(string uu, string du, string er, string cc)
        {
            foreach (Node node in _nodes)
            {
                node.CheckMetrixValues();
            }

            return "";
        }
    }
}
